package com.redes.spamblocker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Se activa al arrancar el dispositivo.
 * Verifica que la protección sigue activa.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            BlockRules rules = new BlockRules(context);
            Log.i("SpamBlocker", "Arranque: protección " + (rules.isEnabled() ? "ACTIVA" : "INACTIVA"));
        }
    }
}
