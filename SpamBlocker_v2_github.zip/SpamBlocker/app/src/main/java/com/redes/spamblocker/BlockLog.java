package com.redes.spamblocker;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Registro persistente de llamadas bloqueadas.
 * Guarda los últimos 200 registros en SharedPreferences como JSON.
 */
public class BlockLog {

    private static final String PREFS_NAME = "SpamBlockerLog";
    private static final String KEY_LOG    = "call_log";
    private static final int    MAX_ENTRIES = 200;

    public static class Entry {
        public final String number;
        public final String reason;
        public final long   timestamp;

        public Entry(String number, String reason, long timestamp) {
            this.number    = number;
            this.reason    = reason;
            this.timestamp = timestamp;
        }

        public String getFormattedDate() {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
            return sdf.format(new Date(timestamp));
        }
    }

    private final SharedPreferences prefs;

    public BlockLog(Context context) {
        prefs = context.getApplicationContext()
                       .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void addEntry(String number, String reason) {
        List<Entry> entries = getEntries();
        entries.add(0, new Entry(number == null ? "Oculto" : number, reason, System.currentTimeMillis()));
        // Limitar a MAX_ENTRIES
        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
        save(entries);
    }

    public List<Entry> getEntries() {
        List<Entry> list = new ArrayList<>();
        String json = prefs.getString(KEY_LOG, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                list.add(new Entry(
                    obj.getString("number"),
                    obj.getString("reason"),
                    obj.getLong("timestamp")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getTotalBlocked() {
        return getEntries().size();
    }

    public void clear() {
        prefs.edit().putString(KEY_LOG, "[]").apply();
    }

    private void save(List<Entry> entries) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : entries) {
                JSONObject obj = new JSONObject();
                obj.put("number",    e.number);
                obj.put("reason",    e.reason);
                obj.put("timestamp", e.timestamp);
                arr.put(obj);
            }
            prefs.edit().putString(KEY_LOG, arr.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
