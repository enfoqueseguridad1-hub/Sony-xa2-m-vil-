package com.redes.spamblocker;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class BlockLogActivity extends AppCompatActivity {

    private BlockLog    blockLog;
    private LogAdapter  adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        blockLog = new BlockLog(this);

        RecyclerView rv = findViewById(R.id.rvLog);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LogAdapter(blockLog.getEntries());
        rv.setAdapter(adapter);

        TextView tvTotal = findViewById(R.id.tvTotal);
        tvTotal.setText("Total bloqueadas: " + blockLog.getTotalBlocked());

        findViewById(R.id.btnClearLog).setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setMessage("¿Borrar todo el registro?")
                .setPositiveButton("Sí", (d, w) -> {
                    blockLog.clear();
                    adapter.update(blockLog.getEntries());
                    tvTotal.setText("Total bloqueadas: 0");
                })
                .setNegativeButton("No", null)
                .show();
        });
    }

    class LogAdapter extends RecyclerView.Adapter<LogAdapter.VH> {
        private List<BlockLog.Entry> items;

        LogAdapter(List<BlockLog.Entry> items) { this.items = items; }

        void update(List<BlockLog.Entry> newItems) {
            this.items = newItems;
            notifyDataSetChanged();
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                       .inflate(R.layout.item_log, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            BlockLog.Entry e = items.get(position);
            holder.tvNumber.setText(e.number);
            holder.tvReason.setText(e.reason);
            holder.tvDate.setText(e.getFormattedDate());

            // Botón añadir a lista negra
            holder.btnBlock.setOnClickListener(v -> {
                BlockRules rules = new BlockRules(BlockLogActivity.this);
                rules.addNumber(e.number);
                Toast.makeText(BlockLogActivity.this,
                    "Añadido a lista negra: " + e.number, Toast.LENGTH_SHORT).show();
            });
        }

        @Override public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView    tvNumber, tvReason, tvDate;
            ImageButton btnBlock;
            VH(View v) {
                super(v);
                tvNumber = v.findViewById(R.id.tvLogNumber);
                tvReason = v.findViewById(R.id.tvLogReason);
                tvDate   = v.findViewById(R.id.tvLogDate);
                btnBlock = v.findViewById(R.id.btnAddToBlacklist);
            }
        }
    }
}
