package com.redes.spamblocker;

import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS    = 100;
    private static final int REQUEST_DEFAULT_DIALER = 101;

    private BlockRules rules;
    private BlockLog   blockLog;

    private Switch   switchEnabled;
    private Switch   switchHidden;
    private Switch   switchIntl;
    private Switch   switchShort;
    private Switch   switchContacts;
    private TextView tvStatus;
    private TextView tvCounter;
    private Button   btnDefaultDialer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rules    = new BlockRules(this);
        blockLog = new BlockLog(this);

        bindViews();
        requestPermissions();
        updateUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }

    private void bindViews() {
        switchEnabled  = findViewById(R.id.switchEnabled);
        switchHidden   = findViewById(R.id.switchHidden);
        switchIntl     = findViewById(R.id.switchIntl);
        switchShort    = findViewById(R.id.switchShort);
        switchContacts = findViewById(R.id.switchContacts);
        tvStatus       = findViewById(R.id.tvStatus);
        tvCounter      = findViewById(R.id.tvCounter);
        btnDefaultDialer = findViewById(R.id.btnDefaultDialer);

        switchEnabled.setOnCheckedChangeListener((b, checked) -> {
            rules.setEnabled(checked);
            updateStatusLabel(checked);
        });
        switchHidden.setOnCheckedChangeListener((b, checked)   -> rules.setBlockHidden(checked));
        switchIntl.setOnCheckedChangeListener((b, checked)     -> rules.setBlockInternational(checked));
        switchShort.setOnCheckedChangeListener((b, checked)    -> rules.setBlockShortNumbers(checked));
        switchContacts.setOnCheckedChangeListener((b, checked) -> {
            rules.setBlockNotInContacts(checked);
            if (checked) {
                new AlertDialog.Builder(this)
                    .setTitle("⚠ Modo máxima protección")
                    .setMessage("Activado: solo pasan llamadas de números que están en tu agenda.\n\n" +
                                "Asegúrate de tener a tu banco, médico y contactos importantes guardados.")
                    .setPositiveButton("Entendido", null)
                    .show();
            }
        });

        btnDefaultDialer.setOnClickListener(v -> promptDefaultDialer());

        findViewById(R.id.btnBlacklist).setOnClickListener(v ->
            startActivity(new Intent(this, BlockListActivity.class)));

        findViewById(R.id.btnPrefixes).setOnClickListener(v ->
            startActivity(new Intent(this, PrefixListActivity.class)));

        findViewById(R.id.btnWhitelist).setOnClickListener(v ->
            startActivity(new Intent(this, WhitelistActivity.class)));

        findViewById(R.id.btnLog).setOnClickListener(v ->
            startActivity(new Intent(this, BlockLogActivity.class)));
    }

    private void updateUI() {
        switchEnabled.setChecked(rules.isEnabled());
        switchHidden.setChecked(rules.blockHidden());
        switchIntl.setChecked(rules.blockInternational());
        switchShort.setChecked(rules.blockShortNumbers());
        switchContacts.setChecked(rules.blockNotInContacts());

        updateStatusLabel(rules.isEnabled());

        // Contador persistente real (no limitado a 200)
        int total = rules.getTotalCount();
        tvCounter.setText(total + " llamadas bloqueadas en total");

        boolean isDefault = isDefaultDialer();
        btnDefaultDialer.setText(isDefault
            ? "✓ App de teléfono por defecto"
            : "⚠ Establecer como teléfono por defecto");
        btnDefaultDialer.setEnabled(!isDefault);
    }

    private void updateStatusLabel(boolean enabled) {
        tvStatus.setText(enabled ? "🛡 PROTECCIÓN ACTIVA" : "⛔ PROTECCIÓN DESACTIVADA");
        tvStatus.setTextColor(enabled ? 0xFF3FB950 : 0xFFF85149);
    }

    private boolean isDefaultDialer() {
        TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
        return tm != null && getPackageName().equals(tm.getDefaultDialerPackage());
    }

    private void promptDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            RoleManager rm = (RoleManager) getSystemService(ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER),
                    REQUEST_DEFAULT_DIALER);
            }
        } else {
            Intent intent = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
            intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
            startActivityForResult(intent, REQUEST_DEFAULT_DIALER);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEFAULT_DIALER) {
            if (isDefaultDialer()) {
                Toast.makeText(this, "✓ Ahora eres el teléfono por defecto. Protección máxima.", Toast.LENGTH_LONG).show();
            } else {
                new AlertDialog.Builder(this)
                    .setTitle("Importante")
                    .setMessage("Sin ser el teléfono por defecto, el bloqueo puede no funcionar en Android 8/9.")
                    .setPositiveButton("Entendido", null)
                    .show();
            }
            updateUI();
        }
    }

    private void requestPermissions() {
        String[] perms = {
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.WRITE_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        };
        boolean needRequest = false;
        for (String p : perms) {
            if (ActivityCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needRequest = true;
                break;
            }
        }
        if (needRequest) {
            ActivityCompat.requestPermissions(this, perms, REQUEST_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQUEST_PERMISSIONS) {
            boolean ok = true;
            for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) { ok = false; break; }
            if (!ok) Toast.makeText(this,
                "⚠ Algunos permisos denegados. El bloqueo puede no funcionar correctamente.",
                Toast.LENGTH_LONG).show();
        }
    }
}
