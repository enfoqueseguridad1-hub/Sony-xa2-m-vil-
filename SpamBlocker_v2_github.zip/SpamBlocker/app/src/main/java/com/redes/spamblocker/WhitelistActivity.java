package com.redes.spamblocker;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * Gestión de la lista blanca — números que NUNCA se bloquean.
 * Prioridad máxima: sobreescribe cualquier otra regla.
 */
public class WhitelistActivity extends AppCompatActivity {

    private BlockRules rules;
    private WhitelistAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        rules = new BlockRules(this);

        TextView title = findViewById(R.id.tvListTitle);
        title.setText("✅ Lista blanca");
        title.setTextColor(0xFF3FB950);   // Verde

        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WhitelistAdapter(rules.getWhitelist());
        rv.setAdapter(adapter);

        TextView hint = findViewById(R.id.tvHint);
        hint.setText("Estos números NUNCA serán bloqueados, aunque coincidan con otras reglas.");

        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setText("+ Añadir a lista blanca");
        btnAdd.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(0xFF3FB950));
        btnAdd.setOnClickListener(v -> showAddDialog());
    }

    private void showAddDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setHint("+34612345678");

        new AlertDialog.Builder(this)
            .setTitle("✅ Añadir a lista blanca")
            .setMessage("Este número nunca será bloqueado.")
            .setView(input)
            .setPositiveButton("Añadir", (d, w) -> {
                String num = input.getText().toString().trim();
                if (!num.isEmpty()) {
                    rules.addWhitelist(num);
                    adapter.update(rules.getWhitelist());
                    Toast.makeText(this, "✅ Añadido: " + num, Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    // ─── Adapter ─────────────────────────────────────────────────────

    class WhitelistAdapter extends RecyclerView.Adapter<WhitelistAdapter.VH> {

        private List<String> items;

        WhitelistAdapter(List<String> items) { this.items = items; }

        void update(List<String> newItems) {
            this.items = newItems;
            notifyDataSetChanged();
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                       .inflate(R.layout.item_rule, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            String item = items.get(position);
            holder.tvNumber.setText("✅ " + item);
            holder.tvNumber.setTextColor(0xFF3FB950);
            holder.btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(WhitelistActivity.this)
                    .setMessage("¿Quitar " + item + " de la lista blanca?")
                    .setPositiveButton("Sí", (d, w) -> {
                        rules.removeWhitelist(item);
                        update(rules.getWhitelist());
                    })
                    .setNegativeButton("No", null)
                    .show();
            });
        }

        @Override public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvNumber;
            ImageButton btnDelete;
            VH(View v) {
                super(v);
                tvNumber  = v.findViewById(R.id.tvRuleText);
                btnDelete = v.findViewById(R.id.btnDeleteRule);
            }
        }
    }
}
