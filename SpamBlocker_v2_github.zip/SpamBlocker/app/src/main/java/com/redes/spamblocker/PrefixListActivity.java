package com.redes.spamblocker;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PrefixListActivity extends AppCompatActivity {

    private BlockRules rules;
    private PrefixAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        rules = new BlockRules(this);

        TextView title = findViewById(R.id.tvListTitle);
        title.setText("🔢 Prefijos bloqueados");

        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PrefixAdapter(rules.getPrefixes());
        rv.setAdapter(adapter);

        TextView hint = findViewById(R.id.tvHint);
        hint.setText("Bloquea cualquier número que empiece por ese prefijo. Ej: +34900 bloquea todos los 900xxx");

        // Botones rápidos — preset España
        LinearLayout llQuickAdd = findViewById(R.id.llQuickAdd);
        llQuickAdd.setVisibility(View.VISIBLE);

        String[] preset = BlockRules.getSpainSpamPreset();
        for (String p : preset) {
            Button btn = new Button(this);
            btn.setText(p);
            btn.setTextSize(11f);
            btn.setPadding(16, 4, 16, 4);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(4, 0, 4, 0);
            btn.setLayoutParams(lp);
            btn.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF21262D));
            btn.setTextColor(0xFFF0883E);
            final String prefix = p;
            btn.setOnClickListener(v -> {
                rules.addPrefix(prefix);
                adapter.update(rules.getPrefixes());
                Toast.makeText(this, "Añadido: " + prefix, Toast.LENGTH_SHORT).show();
            });
            llQuickAdd.addView(btn);
        }

        // Botón "Añadir todos"
        Button btnAll = new Button(this);
        btnAll.setText("⚡ Todos España");
        btnAll.setTextSize(11f);
        btnAll.setPadding(16, 4, 16, 4);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        lp2.setMargins(8, 0, 4, 0);
        btnAll.setLayoutParams(lp2);
        btnAll.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(0xFFDA3633));
        btnAll.setTextColor(0xFFFFFFFF);
        btnAll.setOnClickListener(v -> {
            int added = 0;
            for (String p : BlockRules.getSpainSpamPreset()) {
                rules.addPrefix(p);
                added++;
            }
            adapter.update(rules.getPrefixes());
            Toast.makeText(this, "✅ " + added + " prefijos añadidos", Toast.LENGTH_SHORT).show();
        });
        llQuickAdd.addView(btnAll);

        findViewById(R.id.btnAdd).setOnClickListener(v -> showAddDialog());
    }

    private void showAddDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setHint("+34900");

        new AlertDialog.Builder(this)
            .setTitle("Bloquear prefijo")
            .setView(input)
            .setPositiveButton("Bloquear", (d, w) -> {
                String prefix = input.getText().toString().trim();
                if (!prefix.isEmpty()) {
                    rules.addPrefix(prefix);
                    adapter.update(rules.getPrefixes());
                    Toast.makeText(this, "Bloqueado: " + prefix, Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    // ─── Adapter ─────────────────────────────────────────────────────

    class PrefixAdapter extends RecyclerView.Adapter<PrefixAdapter.VH> {

        private List<String> items;

        PrefixAdapter(List<String> items) { this.items = items; }

        void update(List<String> newItems) {
            this.items = newItems;
            notifyDataSetChanged();
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                       .inflate(R.layout.item_rule, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            String item = items.get(position);
            holder.tvNumber.setText(item + "*");
            holder.btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(PrefixListActivity.this)
                    .setMessage("¿Quitar prefijo " + item + "?")
                    .setPositiveButton("Sí", (d, w) -> {
                        rules.removePrefix(item);
                        update(rules.getPrefixes());
                    })
                    .setNegativeButton("No", null)
                    .show();
            });
        }

        @Override public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvNumber;
            ImageButton btnDelete;
            VH(View v) {
                super(v);
                tvNumber  = v.findViewById(R.id.tvRuleText);
                btnDelete = v.findViewById(R.id.btnDeleteRule);
            }
        }
    }
}
