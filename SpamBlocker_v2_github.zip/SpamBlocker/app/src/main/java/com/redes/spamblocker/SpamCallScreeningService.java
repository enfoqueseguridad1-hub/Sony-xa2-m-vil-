package com.redes.spamblocker;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallScreeningService;
import android.util.Log;

/**
 * CallScreeningService — intercepta llamadas ANTES de que suenen.
 * v2: añade verificación de contactos, lista blanca y contador persistente.
 */
public class SpamCallScreeningService extends CallScreeningService {

    private static final String TAG = "SpamBlocker";

    @Override
    public void onScreenCall(Call.Details callDetails) {
        String rawNumber = null;
        try {
            if (callDetails.getHandle() != null) {
                rawNumber = callDetails.getHandle().getSchemeSpecificPart();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error obteniendo número", e);
        }

        BlockRules rules = new BlockRules(this);
        BlockLog   log   = new BlockLog(this);

        String normNumber = BlockRules.normalize(rawNumber);

        // ── 1. Lista blanca — pasar siempre, sin más comprobaciones ──
        if (!normNumber.isEmpty() && rules.isWhitelisted(normNumber)) {
            Log.i(TAG, "LISTA BLANCA (permitida): " + rawNumber);
            respondToCall(callDetails, new CallResponse.Builder()
                    .setDisallowCall(false).build());
            return;
        }

        // ── 2. Está en contactos + opción "solo contactos" activa ──
        if (rules.blockNotInContacts() && !normNumber.isEmpty()) {
            if (isInContacts(rawNumber)) {
                Log.i(TAG, "EN AGENDA (permitida): " + rawNumber);
                respondToCall(callDetails, new CallResponse.Builder()
                        .setDisallowCall(false).build());
                return;
            }
            // No está en contactos → bloquear directamente
            String reason = "No está en la agenda";
            Log.i(TAG, "BLOQUEADA (no agenda): " + rawNumber);
            log.addEntry(rawNumber, reason);
            rules.incrementTotalCount();
            respondToCall(callDetails, new CallResponse.Builder()
                    .setDisallowCall(true)
                    .setRejectCall(true)
                    .setSilenceCall(true)
                    .setSkipCallLog(false)
                    .build());
            return;
        }

        // ── 3. Reglas normales ────────────────────────────────────────
        boolean block  = rules.shouldBlock(rawNumber);
        String  reason = block ? determineReason(rawNumber, rules) : "";

        CallResponse.Builder response = new CallResponse.Builder();

        if (block) {
            Log.i(TAG, "BLOQUEADA: " + rawNumber + " [" + reason + "]");
            response.setDisallowCall(true)
                    .setRejectCall(true)
                    .setSilenceCall(true)
                    .setSkipCallLog(false);
            log.addEntry(rawNumber, reason);
            rules.incrementTotalCount();
        } else {
            Log.i(TAG, "PERMITIDA: " + rawNumber);
            response.setDisallowCall(false);
        }

        respondToCall(callDetails, response.build());
    }

    /** Verifica si el número está en la agenda de contactos */
    private boolean isInContacts(String number) {
        if (number == null || number.isEmpty()) return false;
        try {
            ContentResolver cr = getContentResolver();
            Uri uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number));
            Cursor cursor = cr.query(uri,
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
                null, null, null);
            if (cursor != null) {
                boolean found = cursor.moveToFirst();
                cursor.close();
                return found;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error verificando agenda", e);
        }
        return false;
    }

    /**
     * Razón de bloqueo — mismo orden de prioridad que shouldBlock().
     */
    private String determineReason(String rawNumber, BlockRules rules) {
        if (rawNumber == null || rawNumber.isEmpty()) return "Número oculto/privado";

        String norm   = BlockRules.normalize(rawNumber);
        String digits = norm.replaceAll("\\D", "");

        if (rules.isNumberBlocked(norm))  return "Lista negra: " + norm;
        if (rules.matchesPrefix(norm))    return "Prefijo bloqueado";

        if (rules.blockShortNumbers() && digits.length() > 0 && digits.length() <= 6)
            return "Número corto (" + digits.length() + " dígitos)";

        if (rules.blockInternational()) {
            boolean isIntl  = norm.startsWith("+") || digits.startsWith("00");
            boolean isSpain = norm.startsWith("+34") || digits.startsWith("0034");
            if (isIntl && !isSpain) return "Internacional";
        }

        return "Regla genérica";
    }
}
