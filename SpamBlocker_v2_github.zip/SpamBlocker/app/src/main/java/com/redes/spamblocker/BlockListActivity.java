package com.redes.spamblocker;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class BlockListActivity extends AppCompatActivity {

    private BlockRules rules;
    private NumberAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        rules = new BlockRules(this);

        TextView title = findViewById(R.id.tvListTitle);
        title.setText("📵 Números bloqueados");

        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NumberAdapter(rules.getNumbers(), false);
        rv.setAdapter(adapter);

        TextView hint = findViewById(R.id.tvHint);
        hint.setText("Añade el número exacto, ej: +34612345678");

        findViewById(R.id.btnAdd).setOnClickListener(v -> showAddDialog());
    }

    private void showAddDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setHint("+34612345678");

        new AlertDialog.Builder(this)
            .setTitle("Bloquear número")
            .setView(input)
            .setPositiveButton("Bloquear", (d, w) -> {
                String num = input.getText().toString().trim();
                if (!num.isEmpty()) {
                    rules.addNumber(num);
                    adapter.update(rules.getNumbers());
                    Toast.makeText(this, "Bloqueado: " + num, Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    // ─── Adapter ───────────────────────────────────────────────────

    class NumberAdapter extends RecyclerView.Adapter<NumberAdapter.VH> {

        private List<String> items;
        private final boolean isPrefix;

        NumberAdapter(List<String> items, boolean isPrefix) {
            this.items    = items;
            this.isPrefix = isPrefix;
        }

        void update(List<String> newItems) {
            this.items = newItems;
            notifyDataSetChanged();
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                       .inflate(R.layout.item_rule, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            String item = items.get(position);
            holder.tvNumber.setText(item);
            holder.btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(BlockListActivity.this)
                    .setMessage("¿Desbloquear " + item + "?")
                    .setPositiveButton("Sí", (d, w) -> {
                        rules.removeNumber(item);
                        update(rules.getNumbers());
                    })
                    .setNegativeButton("No", null)
                    .show();
            });
        }

        @Override public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvNumber;
            ImageButton btnDelete;
            VH(View v) {
                super(v);
                tvNumber  = v.findViewById(R.id.tvRuleText);
                btnDelete = v.findViewById(R.id.btnDeleteRule);
            }
        }
    }
}
