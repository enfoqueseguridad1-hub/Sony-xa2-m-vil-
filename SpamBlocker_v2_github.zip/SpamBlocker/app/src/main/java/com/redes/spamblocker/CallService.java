package com.redes.spamblocker;

import android.telecom.InCallService;

/**
 * InCallService vacío — requerido para que Android 8/9
 * permita a esta app ser el marcador por defecto.
 * Sin este servicio, CallScreeningService no puede colgar llamadas.
 */
public class CallService extends InCallService {
    // Implementación mínima requerida por el sistema.
    // No necesitamos UI de llamada propia; solo el permiso.
}
