package com.redes.spamblocker;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Gestión de reglas de bloqueo — v2.
 * Mejoras: lista blanca, opción contactos, contador total persistente,
 *          preset España, normalización mejorada.
 */
public class BlockRules {

    private static final String PREFS_NAME            = "SpamBlockerPrefs";
    private static final String KEY_NUMBERS           = "blocked_numbers";
    private static final String KEY_PREFIXES          = "blocked_prefixes";
    private static final String KEY_WHITELIST         = "whitelist_numbers";
    private static final String KEY_BLOCK_HIDDEN      = "block_hidden";
    private static final String KEY_BLOCK_INTL        = "block_international";
    private static final String KEY_BLOCK_SHORT       = "block_short_numbers";
    private static final String KEY_BLOCK_CONTACTS    = "block_not_in_contacts";
    private static final String KEY_ENABLED           = "protection_enabled";
    private static final String KEY_TOTAL_COUNT       = "total_blocked_count";

    private final SharedPreferences prefs;

    public BlockRules(Context context) {
        prefs = context.getApplicationContext()
                       .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ─── NÚMEROS EXACTOS (lista negra) ──────────────────────────────

    public void addNumber(String number) {
        number = normalize(number);
        if (number.isEmpty()) return;
        Set<String> set = getMutableNumbers();
        set.add(number);
        prefs.edit().putStringSet(KEY_NUMBERS, set).apply();
    }

    public void removeNumber(String number) {
        Set<String> set = getMutableNumbers();
        set.remove(normalize(number));
        prefs.edit().putStringSet(KEY_NUMBERS, set).apply();
    }

    public List<String> getNumbers() {
        return new ArrayList<>(prefs.getStringSet(KEY_NUMBERS, new HashSet<>()));
    }

    public boolean isNumberBlocked(String number) {
        return getMutableNumbers().contains(normalize(number));
    }

    private Set<String> getMutableNumbers() {
        return new HashSet<>(prefs.getStringSet(KEY_NUMBERS, new HashSet<>()));
    }

    // ─── PREFIJOS ────────────────────────────────────────────────────

    public void addPrefix(String prefix) {
        prefix = normalize(prefix);
        if (prefix.isEmpty()) return;
        Set<String> set = getMutablePrefixes();
        set.add(prefix);
        prefs.edit().putStringSet(KEY_PREFIXES, set).apply();
    }

    public void removePrefix(String prefix) {
        Set<String> set = getMutablePrefixes();
        set.remove(normalize(prefix));
        prefs.edit().putStringSet(KEY_PREFIXES, set).apply();
    }

    public List<String> getPrefixes() {
        return new ArrayList<>(prefs.getStringSet(KEY_PREFIXES, new HashSet<>()));
    }

    public boolean matchesPrefix(String number) {
        number = normalize(number);
        for (String prefix : getMutablePrefixes()) {
            if (number.startsWith(prefix)) return true;
        }
        return false;
    }

    private Set<String> getMutablePrefixes() {
        return new HashSet<>(prefs.getStringSet(KEY_PREFIXES, new HashSet<>()));
    }

    // ─── LISTA BLANCA ────────────────────────────────────────────────

    public void addWhitelist(String number) {
        number = normalize(number);
        if (number.isEmpty()) return;
        Set<String> set = getMutableWhitelist();
        set.add(number);
        prefs.edit().putStringSet(KEY_WHITELIST, set).apply();
    }

    public void removeWhitelist(String number) {
        Set<String> set = getMutableWhitelist();
        set.remove(normalize(number));
        prefs.edit().putStringSet(KEY_WHITELIST, set).apply();
    }

    public List<String> getWhitelist() {
        return new ArrayList<>(prefs.getStringSet(KEY_WHITELIST, new HashSet<>()));
    }

    public boolean isWhitelisted(String number) {
        if (number == null || number.isEmpty()) return false;
        return getMutableWhitelist().contains(normalize(number));
    }

    private Set<String> getMutableWhitelist() {
        return new HashSet<>(prefs.getStringSet(KEY_WHITELIST, new HashSet<>()));
    }

    // ─── OPCIONES GLOBALES ───────────────────────────────────────────

    public boolean isEnabled()           { return prefs.getBoolean(KEY_ENABLED, true); }
    public void setEnabled(boolean v)    { prefs.edit().putBoolean(KEY_ENABLED, v).apply(); }

    public boolean blockHidden()         { return prefs.getBoolean(KEY_BLOCK_HIDDEN, false); }
    public void setBlockHidden(boolean v){ prefs.edit().putBoolean(KEY_BLOCK_HIDDEN, v).apply(); }

    public boolean blockInternational()  { return prefs.getBoolean(KEY_BLOCK_INTL, false); }
    public void setBlockInternational(boolean v){ prefs.edit().putBoolean(KEY_BLOCK_INTL, v).apply(); }

    public boolean blockShortNumbers()   { return prefs.getBoolean(KEY_BLOCK_SHORT, false); }
    public void setBlockShortNumbers(boolean v){ prefs.edit().putBoolean(KEY_BLOCK_SHORT, v).apply(); }

    /** Solo bloquea llamadas de números que NO están en la agenda */
    public boolean blockNotInContacts()  { return prefs.getBoolean(KEY_BLOCK_CONTACTS, false); }
    public void setBlockNotInContacts(boolean v){ prefs.edit().putBoolean(KEY_BLOCK_CONTACTS, v).apply(); }

    // ─── CONTADOR TOTAL PERSISTENTE ──────────────────────────────────

    /** Total histórico de llamadas bloqueadas (no limitado a 200) */
    public int getTotalCount() {
        return prefs.getInt(KEY_TOTAL_COUNT, 0);
    }

    public void incrementTotalCount() {
        prefs.edit().putInt(KEY_TOTAL_COUNT, getTotalCount() + 1).apply();
    }

    // ─── LÓGICA PRINCIPAL — shouldBlock() ────────────────────────────

    /**
     * Decide si bloquear una llamada.
     * Orden de prioridad:
     *   1. Lista blanca → NUNCA bloquear
     *   2. Lista negra exacta → bloquear
     *   3. Prefijos → bloquear
     *   4. Número corto → bloquear (si activo)
     *   5. Internacional no-España → bloquear (si activo)
     *   (Los contactos se verifican en el servicio antes de llamar aquí)
     */
    public boolean shouldBlock(String rawNumber) {
        if (!isEnabled()) return false;

        // Número oculto / privado
        if (rawNumber == null || rawNumber.isEmpty()) {
            return blockHidden();
        }

        String number = normalize(rawNumber);

        // 1. Lista blanca — prioridad máxima
        if (isWhitelisted(number)) return false;

        // 2. Lista negra exacta
        if (isNumberBlocked(number)) return true;

        // 3. Prefijo bloqueado
        if (matchesPrefix(number)) return true;

        // 4. Número corto ≤6 dígitos (telemarketing, SMS premium)
        String digits = number.replaceAll("\\D", "");
        if (blockShortNumbers() && digits.length() > 0 && digits.length() <= 6) return true;

        // 5. Internacional: empieza por + o 00, pero NO es España (+34 / 0034)
        if (blockInternational()) {
            boolean isIntl  = number.startsWith("+") || digits.startsWith("00");
            boolean isSpain = number.startsWith("+34") || digits.startsWith("0034");
            if (isIntl && !isSpain) return true;
        }

        return false;
    }

    // ─── PRESET PREFIJOS SPAM ESPAÑA ─────────────────────────────────

    /** Prefijos de spam más habituales en España — para añadir de un clic */
    public static String[] getSpainSpamPreset() {
        return new String[]{
            "+34900",   // Gratuitos empresa — spam masivo
            "+34901",   // Tarificación especial
            "+34902",   // Tarificación especial — call centers
            "+34905",   // Tarificación especial
            "+34800",   // Gratuitos empresa
            "+34803",   // Acceso a servicios
            "+34806",   // Servicios de valor añadido
            "+34807",   // Servicios de valor añadido
        };
    }

    // ─── UTILIDADES ──────────────────────────────────────────────────

    /**
     * Normaliza un número: quita espacios, guiones, paréntesis, puntos.
     * Ejemplos: "+34 612-345.678" → "+34612345678"
     *           "(+34) 91 234 56 78" → "+34912345678"
     */
    public static String normalize(String number) {
        if (number == null) return "";
        return number.trim().replaceAll("[\\s\\-\\(\\)\\.\\\\]", "");
    }
}
