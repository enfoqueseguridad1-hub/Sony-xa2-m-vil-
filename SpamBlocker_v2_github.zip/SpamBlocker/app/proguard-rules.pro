# Reglas ProGuard para SpamBlocker
# Por defecto vacío — minifyEnabled está desactivado en debug
