# SpamBlocker — Sony Xperia XA2 (Android 8/9)

App nativa Android para bloquear llamadas spam automáticamente.

## Características

- **CallScreeningService**: intercepta la llamada ANTES de que suene
- **Lista negra**: números exactos bloqueados
- **Prefijos**: bloquea p.ej. todos los +34900xxx, +34800xxx
- **Número oculto**: opción para bloquear llamadas sin número
- **Internacional**: bloquea todo excepto España (+34)
- **Números cortos**: bloquea números ≤6 dígitos (telemarketing automático)
- **Registro**: historial de todas las llamadas bloqueadas con motivo y fecha
- **Interfaz oscura**: optimizada para Sony XA2

---

## COMPILAR (PC con Android Studio)

### Requisitos
- Android Studio Giraffe (2022.3.1) o superior
- JDK 11 o 17
- Android SDK 33

### Pasos
1. Abrir Android Studio → `File > Open` → seleccionar esta carpeta
2. Esperar sincronización de Gradle (~2-5 minutos primera vez)
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`
4. APK en: `app/build/outputs/apk/debug/app-debug.apk`
5. Pasar el APK al Sony XA2 (WhatsApp, cable USB, etc.)

---

## INSTALAR EN SONY XA2

### Activar instalación de fuentes desconocidas (Android 8)
1. `Ajustes → Apps y notificaciones → Avanzado → Acceso especial a apps`
2. `Instalar apps desconocidas → Chrome/WhatsApp → Permitir`

### Instalar
1. Abrir el APK desde el móvil
2. Pulsar "Instalar"

### Configurar (MUY IMPORTANTE)
1. Abrir SpamBlocker
2. Pulsar **"Establecer como teléfono por defecto"** → aceptar
   - Sin esto, en Android 8/9 el servicio NO puede colgar llamadas
3. Conceder todos los permisos solicitados
4. Activar el interruptor principal

### Añadir reglas spam España
En **Prefijos bloqueados**:
- `+34900` → números 900 (gratuitos usados para spam)
- `+34901` → tarificación especial
- `+34902` → tarificación especial  
- `+34800` → gratuitos empresa
- `+34803` → acceso a servicios

---

## CÓMO FUNCIONA (Android 8/9)

```
Llamada entrante
      ↓
CallScreeningService.onScreenCall()
      ↓
BlockRules.shouldBlock(número)
   ├── ¿Número oculto? → opción usuario
   ├── ¿En lista negra exacta? → BLOQUEAR
   ├── ¿Empieza por prefijo bloqueado? → BLOQUEAR
   ├── ¿Número corto? → opción usuario
   ├── ¿Internacional no-España? → opción usuario
   └── No coincide → PERMITIR
      ↓
Si BLOQUEAR:
  - setDisallowCall(true)  → no pasa al marcador
  - setRejectCall(true)    → cuelga
  - setSilenceCall(true)   → sin sonido ni vibración
  - Guarda en BlockLog
      ↓
Si PERMITIR:
  - Llamada normal
```

---

## ARCHIVOS PRINCIPALES

| Archivo | Función |
|---------|---------|
| `SpamCallScreeningService.java` | Intercepta y evalúa cada llamada |
| `BlockRules.java` | Lógica de bloqueo + almacenamiento de reglas |
| `BlockLog.java` | Registro de llamadas bloqueadas |
| `MainActivity.java` | Pantalla principal + switches |
| `BlockListActivity.java` | Gestión de números exactos |
| `PrefixListActivity.java` | Gestión de prefijos |
| `BlockLogActivity.java` | Ver historial de bloqueadas |

---

## LIMITACIÓN CONOCIDA EN ANDROID 8/9

En Android 10+ cualquier app puede ser "call screener" sin ser el marcador por defecto.
En Android 8/9, `CallScreeningService` necesita que la app sea la **aplicación de teléfono por defecto** para poder rechazar llamadas. Al establecerla como tal, reemplaza el marcador Sony — el marcador original se puede restaurar en cualquier momento desde Ajustes.
